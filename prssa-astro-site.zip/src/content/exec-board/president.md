---
name: Alex Taylor
role: President
bio: Senior PR student passionate about strategic communications and leadership.
---