---
name: Jamie Lin
role: Vice President
bio: Organizes events and assists in member engagement efforts.
---