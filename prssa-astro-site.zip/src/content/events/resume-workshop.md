---
title: Resume Workshop
date: 2025-11-07
location: Room 204, Comms Building
description: Get your resume reviewed by PR pros and polish your LinkedIn profile.
---