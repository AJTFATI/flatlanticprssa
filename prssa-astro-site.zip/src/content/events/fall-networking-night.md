---
title: Fall Networking Night
date: 2025-10-15
location: Student Union Ballroom
description: Join us for a night of networking with local PR professionals and alumni.
---